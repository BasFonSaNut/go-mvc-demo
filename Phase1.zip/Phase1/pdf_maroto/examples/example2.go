package examples

import (
	"fmt"
	"os"
	"time"

	"github.com/johnfercher/maroto/pkg/consts"
	"github.com/johnfercher/maroto/pkg/pdf"
	"github.com/johnfercher/maroto/pkg/props"
)

func Example2(fileName string) (successflag bool, err error) {
	begin := time.Now()
	m := pdf.NewMaroto(consts.Portrait, consts.Letter)
	m.SetBorder(true)

	m.Row(40, func() {
		//https://promptpay.io/your_mobile_number/amount
		m.Col(2, func() {
			m.QrCode("https://promptpay.io/0801254687/500", props.Rect{
				Percent: 50,
			})
		})
		m.Col(4, func() {
			m.QrCode("https://promptpay.io/0802568794/700", props.Rect{
				Percent: 75,
			})
		})
		m.Col(6, func() {
			m.QrCode("https://promptpay.io/0803947856/900", props.Rect{
				Percent: 100,
			})
		})
	})

	pdfFile := "pdfoutput/" + fileName
	err = m.OutputFileAndClose(pdfFile)
	if err != nil {
		fmt.Println("Could not save PDF:", err)
		os.Exit(1)
	}

	end := time.Now()
	fmt.Println(end.Sub(begin)) //เริ่มจับเวลา executetime แล้ว print เวลาที่ใช้ในการประมวลผล ออกมา
	return
}
