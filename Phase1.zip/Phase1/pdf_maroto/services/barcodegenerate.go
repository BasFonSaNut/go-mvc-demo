package services

import (
	"image/png"
	"os"

	"github.com/makiuchi-d/gozxing"
	"github.com/makiuchi-d/gozxing/oned"
)

func GenerateBarcode(fName string) (success bool, err error) {

	enc := oned.NewCode128Writer()
	img, _ := enc.Encode("250BATH", gozxing.BarcodeFormat_CODE_128, 250, 50, nil)

	file, _ := os.Create("assets/images/barcodegenerate/" + fName)
	defer file.Close()

	// *BitMatrix implements the image.Image interface,
	// so it is able to be passed to png.Encode directly.
	_ = png.Encode(file, img)

	dir, err := os.Getwd()
	// fmt.Println("Current pwd barcode", dir)
	fullpath := dir + "\\assets\\images\\barcodegenerate\\" + fName
	found, err := DoesFileExist(fullpath)
	if found == true {
		success = true
	} else {
		success = false
	}

	return

}
