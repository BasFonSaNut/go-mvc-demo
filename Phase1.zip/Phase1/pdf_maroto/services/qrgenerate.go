package services

// ส่วนการประมวลผลไฟล์ สามารถใช้ package "io/fs" แทนได้ง่ายกว่า ,https://pkg.go.dev/io/fs@go1.21.0
import (
	"fmt"
	"io"
	"log"
	"os"
	"os/exec"
)

// func init() {
// 	fmt.Println("this is fileservice package")
// }

func GenerateQrcode(outfilename string) (successflag bool, err error) {
	fmt.Println("Generating QR Code")
	url := "https://promptpay.io/0802949715/500"
	fsave := "-o" + outfilename
	//fsave := "-O --output-dir assets/images/qrcodegenerate -o"+outfilename // ถ้าเครื่องใคร curl ไม่มีปัญหา รันบรรทัดนี้แทน บรรทัด

	cmd := exec.Command("curl", fsave, url)
	cmd.Run()

	// exec.Command("curl", "-o filename", "https://promptpay.io/0802949715/500") เกิดช่องว่างให้ใช้การต่อ string

	if len(os.Args) < 1 {
		// If argument is not provided quit
		log.Fatalln("url not provided")
		successflag = false
	} else {
		successflag = true
	}

	return
}

func RenameFilename(oldfilename, outfilename string) (successflag bool, err error) {
	// source and destionation name
	fmt.Println(oldfilename, outfilename)
	src := oldfilename
	dst := outfilename

	// rename file
	err = os.Rename(src, dst)
	if err != nil {
		successflag = false
	} else {
		successflag = true
	}
	return
}

func MoveFile(sourcePath, destPath, fName string) (successflag bool, err error) {
	srcFile := sourcePath + "\\" + fName
	destFile := destPath + "\\" + fName
	inputFile, err := os.Open(srcFile)

	if err != nil {
		fmt.Println("Couldn't open source file: ", err)
		successflag = false
	}
	outputFile, err := os.Create(destFile)
	if err != nil {
		inputFile.Close()
		fmt.Println("Couldn't open dest file: ", err)
		successflag = false
	}

	defer outputFile.Close()
	_, err = io.Copy(outputFile, inputFile)
	inputFile.Close()
	if err != nil {
		log.Fatal(err)
		fmt.Println("Writing to output file failed: ", err)
		successflag = false
	}
	// The copy was successful, so now delete the original file
	err = os.Remove(srcFile)
	if err != nil {
		log.Fatal(err)
		fmt.Println("Failed removing original file: ", err)
		successflag = false
	} else {
		successflag = true
	}
	return
}

func ReadFileCurrentDir() {
	file, err := os.Open(".")
	if err != nil {
		log.Fatal(err)
		fmt.Println("Failed removing original file: ", err)
	}
	defer file.Close()

	list, _ := file.Readdirnames(0) // 0 to read all files and folders
	for _, name := range list {
		fmt.Println(name)
	}
}

func DoesFileExist(path string) (found bool, err error) {
	if _, err = os.Stat(path); err != nil {
		if os.IsNotExist(err) {
			err = nil
		}
	} else {
		found = true
	}

	return
}
