package main

import (
	"fmt"
	"os"
	"pdf_maroto/examples"
	"pdf_maroto/services"
)

func main() {
	qrcodeFile := "qr700bath1.png"
	success, err := services.GenerateQrcode(qrcodeFile)
	if err != nil {
		fmt.Println(success, err)
		panic(err)
	} else {
		fmt.Println("Generated Qr Success")
	}

	dir, err := os.Getwd()
	fullpath := dir + "\\" + qrcodeFile
	found, err := services.DoesFileExist(fullpath)
	fmt.Println("Output file Found :", found)
	if found == true {
		destPath := dir + "\\assets\\images\\qrcodegenerate"
		success, err := services.MoveFile(dir, destPath, qrcodeFile)
		// ถ้าเครื่องใคร curl ไม่มีปัญหา รันบรรทัด curl pattern ล่างได้
		///fsave := "-O --output-dir assets/images/qrcodegenerate -o"+outfilename
		// ไม่จำเป็นต้อง move file ไปยัง \\assets\\images\\qrcodegenerate เอง ให้ remark บรรทัด 26,48-50

		if success == true {
			fmt.Println("Move file Success :", success)
			fmt.Println("Barcode Generating")
			barCodeFile := "Barcode221.png"
			success, err := services.GenerateBarcode(barCodeFile)
			if success == true {
				fmt.Println("Generated Barcode Success: ", success)
				pdfFile := "example1.pdf"
				success, err := examples.Example1(pdfFile)
				if success == true {
					fmt.Println("Create PDF Success: ", success)
				} else {
					fmt.Println("Create PDF Fail: ", err)
				}
			} else {
				fmt.Println("Generate Barcode Fail :", err)
			}
		} else {
			fmt.Println("Error :", err)
		}

	} else {
		fmt.Println("Error ", err)
		panic(err)
	}

	// success, err = examples.Example2("exmple2.pdf")
	// fmt.Println("Success ?", success)
}
