package data

import (
	"fmt"

	"github.com/brianvoe/gofakeit/v6"
)

//ใช้ dummy data กับทาง https://github.com/brianvoe/gofakeit/ ไปก่อน
// เพราะไม่มีเวลามานั่งพิมพ์ และยังไม่มีหน้าตาส่วน input
// ให้เรียนรู้ pdf package ที่ใช้โปรเจคตัวนี้
/*
The GoFakeIt packages gives us all sorts of functions for concepts such as a File, a Person, a Number,
among other things. We will be using Fruit in this tutorial.

We can represent the structure of each fruit item using a Fruit struct type.
Each Fruit will have a Name, a Description and a Price.
Each of these values will be randomly generated using GoFakeIt.
https://github.com/brianvoe/gofakeit/
*/
type Fruit struct {
	Name        string  `fake:"{carfueltype}"`
	Description string  `fake:"{loremipsumsentence:10}"`
	Price       float64 `fake:"{price:10,20}"`
}

/*
Name: call https://github.com/brianvoe/gofakeit/ ,send parameter to get random list
Description : random sentence
Price : random price value between 10 and 20
*/
func generateFruit() []string {
	var f Fruit
	gofakeit.Struct(&f)

	froot := []string{}
	froot = append(froot, f.Name)
	froot = append(froot, f.Description)
	froot = append(froot, fmt.Sprintf("%.2f", f.Price))

	return froot
}

func FruitList(length int) [][]string {
	var fruits [][]string

	for i := 0; i < length; i++ {
		ff := generateFruit()
		fruits = append(fruits, ff)
	}

	return fruits
}
