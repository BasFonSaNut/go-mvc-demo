package services

import (
	"fmt"
	"time"
)

func GetCurrentDateTimeForDB() (currentTime string) {
	//2023-08-26 15:09:16
	ctime := time.Now()
	// fmt.Println("YYYY-MM-DD hh:mm:ss : ", ctime.Format("2006-01-02 15:04:05"))
	currentTime = ctime.Format("2006-01-02 15:04:05")
	return

}

func getCurrentDateTime() {
	now := time.Now()
	fmt.Println("Current date and time (RFC3339):", now.Format(time.RFC3339))
	//output
	//Current date and time (RFC3339): 2023-05-04T17:02:52Z
}
func getCurrentDate() {
	now := time.Now()
	fmt.Println("Current date (YYYY-MM-DD):", now.Format("2006-01-02"))
	//output
	//Current date (YYYY-MM-DD): 2023-05-04
}

func getCurrentTime() {
	now := time.Now()
	fmt.Println("Current time (HH:MM:SS):", now.Format("15:04:05"))
	//output
	//Current time (HH:MM:SS): 17:02:52

}
func getCurentDateTimeFull() {
	now := time.Now()
	fmt.Println("Current date and time (Mon Jan 2 15:04:05 MST 2006):", now.Format("Mon Jan 2 15:04:05 MST 2006"))
	//output
	//Current date and time (Mon Jan 2 15:04:05 MST 2006): Thu May 4 17:02:52 UTC 2023
}
