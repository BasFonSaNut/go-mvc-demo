package controllers

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"math/rand"
	"net/http"
	"os"

	"go-gorm-fiber-colly-mysql/helpers"
	"go-gorm-fiber-colly-mysql/initializers"
	"go-gorm-fiber-colly-mysql/models"
	"go-gorm-fiber-colly-mysql/services"
	"strconv"
	"strings"

	"github.com/brianvoe/gofakeit/v6"
	"github.com/gocolly/colly/v2"
	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"
)

type Data struct {
	URL      string
	FileName string
}

type item struct {
	Name          string `json:"name"`
	Price         string `json:"price"`
	PriceFormater string `json:"priceformater"`
	ImgUrl        string `json:"imgurl"`
}

func ProductClearData(c *fiber.Ctx) error {
	initializers.DB.Exec("TRUNCATE table `Products3`") //clear data ออกจาก database ทั้งหมด
	pagination := helpers.GetpaginationData(1, 10, &models.Products3{}, "/product")
	// Get the people
	var production []models.Products3
	//initializers.DB.Find(&production) //all record
	initializers.DB.Limit(10).Offset(0).Find(&production)

	// Render the page
	return c.Render("production/index", fiber.Map{
		"production": production,
		"pagination": pagination,
	})
}

func ProductCreateTestData(c *fiber.Ctx) error {
	initializers.DB.Exec("TRUNCATE table `Products3`") //clear data ออกจาก database ทั้งหมด
	//อยาก random data อะไรให้ gofakeit. เช็ค แล้วนำ properties ไปใส่ใน struct ด้วยอักษรเล็กหมด

	for i := 0; i < 500; i++ {
		var f models.FakeProduct
		gofakeit.Struct(&f)
		Pname := f.PName
		PDdesc := f.PDesc
		PPrice := f.PPrice
		product := models.Products3{
			Productname:        Pname,
			Productdescription: PDdesc,
			Productprice:       PPrice,
		}
		initializers.DB.Save(&product)
	}

	pagination := helpers.GetpaginationData(1, 10, &models.Products3{}, "/product")
	// Get the people
	var production []models.Products3
	//initializers.DB.Find(&production) //all record
	initializers.DB.Limit(10).Offset(0).Find(&production)

	// Render the page
	return c.Render("production/index", fiber.Map{
		"production": production,
		"pagination": pagination,
	})

}

func ProductIndex(c *fiber.Ctx) error {
	//Get page number
	perPage := 10
	page := 1
	pageStr := c.Params("page")
	productname := c.FormValue("productname")

	if pageStr != "" {
		page, _ = strconv.Atoi(pageStr)
	}

	var tmplike = ""
	if productname != "" {
		str := []string{"%", productname, "%"}
		tmplike = strings.Join(str, "")
	}

	pagination := helpers.GetpaginationData(page, perPage, &models.Products3{}, "/product")
	// Get the people
	var production []models.Products3
	//initializers.DB.Find(&production) //all record
	if productname != "" {
		initializers.DB.Where("Productname LIKE ?", tmplike).Limit(perPage).Offset(pagination.Offset).Find(&production)
	} else {
		initializers.DB.Limit(perPage).Offset(pagination.Offset).Find(&production)
	}

	// set price formate by humanize
	// for _, x := range production {
	// 	//strx := fmt.Sprint(x.Productprice)
	// 	x.Priceformater = humanize.Commaf(float64(x.Productprice))
	// }

	// Render the page
	return c.Render("production/index", fiber.Map{
		"production": production,
		"pagination": pagination,
	})
}

func ProductSearch(c *fiber.Ctx) error {
	//Get page number
	perPage := 10
	page := 1
	pageStr := c.Params("page")
	searchword := c.Params("searchword")
	if pageStr != "" {
		page, _ = strconv.Atoi(pageStr)
	}

	var templike string = ""
	if searchword != "" {
		str := []string{"%", searchword, "%"}
		templike = strings.Join(str, "")
	}

	var production []models.Products3
	var allRows int64
	var offSet = (page - 1) * 10

	initializers.DB.Where("Productname LIKE ?", templike).Find(&production).Count(&allRows)
	fmt.Println("No of Row is ", allRows)

	totalRows, pagestatic := helpers.GetpaginationSearchwordData(page, perPage, allRows, &models.Products3{}, "/product", searchword)
	var productionreturn []models.Products3
	initializers.DB.Where("Productname LIKE ?", templike).Limit(perPage).Offset(offSet).Find(&productionreturn)

	// Render the page
	return c.Render("production/indexsearch", fiber.Map{
		"production": productionreturn,
		"totalrow":   totalRows,
		"pagestatic": pagestatic,
	})
}

func SearchProduct(c *fiber.Ctx) error {
	//Get page number

	perPage := 10
	page := 1
	pageStr := c.Params("page")
	searchword := c.FormValue("findword")

	fmt.Println("Page No", pageStr)
	if pageStr != "" {
		page, _ = strconv.Atoi(pageStr)
	}

	var templike string = ""
	if searchword != "" {
		str := []string{"%", searchword, "%"}
		templike = strings.Join(str, "")
		fmt.Println("First search word ", searchword)
	}

	var production []models.Products3
	var allRows int64
	initializers.DB.Where("Productname LIKE ?", templike).Find(&production).Count(&allRows)
	fmt.Println("No of Row is ", allRows)
	initializers.DB.Where("Productname LIKE ?", templike).Limit(10).Offset(0).Find(&production)

	totalRows, pagestatic := helpers.GetpaginationSearchwordData(page, perPage, allRows, &models.Products3{}, "/product", searchword)

	return c.Render("production/indexsearch", fiber.Map{
		"production": production,
		"totalrow":   totalRows,
		"pagestatic": pagestatic,
	})
}

func ProductInsertForm(c *fiber.Ctx) error {
	// Render the page
	resultAction := models.ActionResult{
		Title:   "",
		Content: "",
	}
	//fmt.Println(result.Title)
	return c.Render("production/insertform", fiber.Map{
		"result": resultAction,
	})
}

func InsertProduct(c *fiber.Ctx) error {
	r, err := c.MultipartForm() //10 MB
	if err != nil {
		return c.SendString("Your Form didn't set multipart/form-data!")
	}

	fmt.Println(r)
	dir, err := os.Getwd()

	fileHeader, err := c.FormFile("imgInp")
	tmppathimage := dir + "\\public\\assets\\uploadfile\\images"

	tmppathpdf := dir + "\\public\\assets\\uploadfile\\PDFs"
	tmppathdoc := dir + "\\public\\assets\\uploadfile\\doc"

	file, err := c.FormFile("imgInp")
	var filelocation_fordb string
	filelocation_fordb = ""
	if file != nil {
		contentType := fileHeader.Header["Content-Type"][0]
		if err == nil {
			fmt.Println("Content Type:", contentType)
			fmt.Printf("fileHeader.Filename: %v\n", fileHeader.Filename)
			fmt.Printf("fileHeader.Size (bytes): %d\n", fileHeader.Size)
			fmt.Printf("fileHeader.Size (kilobytes): %d\n", fileHeader.Size/1024)
			fmt.Printf("fileHeader.Header: %v\n", fileHeader.Header)

			if contentType == "image/jpeg" {
				filelocation_fordb = "/assets/uploadfile/images/" + fileHeader.Filename
				c.SaveFile(file, fmt.Sprintf("%s\\%s", tmppathimage, file.Filename))
			} else if contentType == "application/pdf" {
				filelocation_fordb = "/assets/uploadfile/PDFs/" + fileHeader.Filename
				c.SaveFile(file, fmt.Sprintf("%s\\%s", tmppathpdf, file.Filename))
			} else if contentType == "application/msword" {
				filelocation_fordb = "/assets/uploadfile/doc/" + fileHeader.Filename
				c.SaveFile(file, fmt.Sprintf("%s\\%s", tmppathdoc, file.Filename))

			}
		}
	}
	//db insert
	pname := c.FormValue("Productname")
	pdesc := c.FormValue("Productdescription")
	pprice := c.FormValue("Productprice")

	initializers.DB.Model(&models.Products3{}).Create(map[string]interface{}{
		"Productname": pname, "Productdescription": pdesc, "Productprice": pprice, "Urlproduct_Image": filelocation_fordb,
	})

	resultinsert := &models.Products3{}
	initializers.DB.Where("Productname = ? and Productdescription = ? and Productprice = ? and urlproduct_image = ?", pname, pdesc, pprice, filelocation_fordb).First(&resultinsert)
	fmt.Println("LAST EFFECT ROW IS, ", resultinsert.Id)

	resultAction := models.ActionResult{
		Title:   "Insert success, ",
		Content: "ready to update.",
	}
	return c.Render("production/updateform", fiber.Map{
		"production": resultinsert,
		"result":     resultAction,
	})
}

func ProductUpdateFrom(c *fiber.Ctx) error {
	id := c.Params("id")
	toUpdateRec := &models.Products3{}
	initializers.DB.Where("Id = ?", id).First(&toUpdateRec)
	fmt.Println("Record to be update ID : ", toUpdateRec.Id)
	resultAction := models.ActionResult{
		Title:   "ID :" + id + ", ",
		Content: "ready to update.",
	}

	return c.Render("production/updateform", fiber.Map{
		"production": toUpdateRec,
		"result":     resultAction,
	})

}

func UpdateProduct(c *fiber.Ctx) error {
	r, err := c.MultipartForm() //10 MB
	if err != nil {
		return c.SendString("Your Form didn't set multipart/form-data!")
	}

	fmt.Println(r)
	dir, err := os.Getwd()

	fileHeader, err := c.FormFile("imgInp")
	tmppathimage := dir + "\\public\\assets\\uploadfile\\images"

	tmppathpdf := dir + "\\public\\assets\\uploadfile\\PDFs"
	tmppathdoc := dir + dir + "\\public\\assets\\uploadfile\\doc"

	file, err := c.FormFile("imgInp")
	var filelocation_fordb string
	filelocation_fordb = ""
	if file != nil {
		contentType := fileHeader.Header["Content-Type"][0]
		if err == nil {
			fmt.Println("Content Type:", contentType)
			fmt.Printf("fileHeader.Filename: %v\n", fileHeader.Filename)
			fmt.Printf("fileHeader.Size (bytes): %d\n", fileHeader.Size)
			fmt.Printf("fileHeader.Size (kilobytes): %d\n", fileHeader.Size/1024)
			fmt.Printf("fileHeader.Header: %v\n", fileHeader.Header)

			if contentType == "image/jpeg" {
				filelocation_fordb = "/assets/uploadfile/images/" + fileHeader.Filename
				c.SaveFile(file, fmt.Sprintf("%s\\%s", tmppathimage, file.Filename))
			} else if contentType == "application/pdf" {
				filelocation_fordb = "/assets/uploadfile/PDFs/" + fileHeader.Filename
				c.SaveFile(file, fmt.Sprintf("%s\\%s", tmppathpdf, file.Filename))
			} else if contentType == "application/msword" {
				filelocation_fordb = "/assets/uploadfile/doc/" + fileHeader.Filename
				c.SaveFile(file, fmt.Sprintf("%s\\%s", tmppathdoc, file.Filename))
			}
		}
	}

	//db insert
	Id := c.FormValue("Id")
	pname := c.FormValue("Productname")
	pdesc := c.FormValue("Productdescription")
	pprice := c.FormValue("Productprice")
	pimage := c.FormValue("Urlproduct_Image")

	if filelocation_fordb == "" && pimage != "" {
		initializers.DB.Model(&models.Products3{}).Where("Id = ?", Id).Updates(map[string]interface{}{
			"Productname": pname, "Productdescription": pdesc, "Productprice": pprice, "Urlproduct_Image": pimage,
		})
	} else if filelocation_fordb != "" && pimage == "" {
		initializers.DB.Model(&models.Products3{}).Where("Id = ?", Id).Updates(map[string]interface{}{
			"Productname": pname, "Productdescription": pdesc, "Productprice": pprice, "Urlproduct_Image": filelocation_fordb,
		})
	} else if filelocation_fordb != "" && pimage != "" {
		initializers.DB.Model(&models.Products3{}).Where("Id = ?", Id).Updates(map[string]interface{}{
			"Productname": pname, "Productdescription": pdesc, "Productprice": pprice, "Urlproduct_Image": filelocation_fordb,
		})
	}
	toUpdateRec := &models.Products3{}
	initializers.DB.Where("Id = ?", Id).First(&toUpdateRec)

	resultAction := models.ActionResult{
		Title:   "Update success, ",
		Content: "ready for next update.",
	}

	return c.Render("production/updateform", fiber.Map{
		"production": toUpdateRec,
		"result":     resultAction,
	})
}

func DeleteProduct(c *fiber.Ctx) error {
	id := c.Params("id")

	initializers.DB.Delete(&models.Products3{}, id)
	fmt.Println("Record was deleted ID : ", id)
	return ProductIndex(c)
}

func ScrapProduct(c *fiber.Ctx) error {
	// Instantiate default collector

	coll := colly.NewCollector(
		colly.AllowedDomains("www.jib.co.th"),
	)

	// struct ใช้ตามถนัด เลยได้ทั้งสองแบบ
	data := []item{}
	dir, err1 := os.Getwd()
	if err1 != nil {
		logrus.Error(err1)
	}

	jsonfilename, err2 := services.GenerateRandomString(10)
	if err2 != nil {
		// Serve an appropriately vague error to the
		// user, but log the details internally.
		logrus.Error(err2)
	}

	tmppathjson := dir + "\\public\\assets\\jsonfile\\" + jsonfilename + ".json"

	coll.OnHTML("div[class='reladiv']", func(e *colly.HTMLElement) {
		productdescription := e.ChildText("a[href]")
		fmt.Println(productdescription)

		productprice := e.ChildText("p[class=price_total]")
		fmt.Println(productprice)

		//var intPrice int
		strReplacePrice := strings.ReplaceAll(productprice, ",", "")
		strReplacePrice = strings.ReplaceAll(strReplacePrice, ".-", "")

		imageurl := e.ChildAttr("img", "src")
		imageurlconcat := "https://www.jib.co.th" + imageurl
		fmt.Println(imageurl)

		newitem := &item{
			Name:          productdescription,
			Price:         strReplacePrice,
			PriceFormater: productprice,
			ImgUrl:        imageurlconcat,
		}

		data = append(data, *newitem)
		dataBytes1, err3 := json.Marshal(data)
		if err3 != nil {
			logrus.Error(err3)
		}

		err4 := os.WriteFile(tmppathjson, dataBytes1, 0644)
		if err4 != nil {
			logrus.Error(err4)
		}
		//fmt.Println(len(data))
	})

	// Before making a request print "Visiting ..."
	// c.OnRequest(func(r *colly.Request) {
	// 	fmt.Println("Visiting", r.URL.String())
	// })

	// Start scraping on https://www.jib.co.th/web/product/product_list/2/2
	coll.Visit("https://www.jib.co.th/web/product/product_list/2/2")

	err5 := ReadjsonfileAndSaveImageInsertDB(tmppathjson)
	if err5 != nil {
		logrus.Error(err5)
	}

	return ProductIndex(c)
}

func ReadjsonfileAndSaveImageInsertDB(jsonfullpath string) error {
	content, err := os.ReadFile(jsonfullpath)
	if err != nil {
		fmt.Println(err.Error())
	}
	var jsonItem []item
	err2 := json.Unmarshal(content, &jsonItem)
	if err2 != nil {
		fmt.Println("Error JSON Unmarshalling")
		fmt.Println(err2.Error())
	}

	for _, x := range jsonItem {
		fmt.Printf("Name: %s, Price: %s, PriceFormater: %s, ImgUrl: %s \n", x.Name, x.Price, x.PriceFormater, x.ImgUrl)
		imagefilename := strings.Split(x.ImgUrl[strings.LastIndex(x.ImgUrl, "/")+1:], "?")[:1][0]
		filelocation_fordb := "/assets/uploadfile/images/" + imagefilename
		dataTestdownload := &Data{
			URL:      x.ImgUrl,
			FileName: imagefilename,
		}
		err3 := dataTestdownload.downoad()
		if err3 != nil {
			fmt.Println(err3.Error())
		}

		str := "SMARTPHONE (สมาร์ทโฟน) "
		var length = len([]rune(str))
		productname := x.Name[length+17 : (length + 40)]
		//productiondesc := x.Name[(length + 40):]
		//fmt.Println(humanize.Comma(x.Price))
		//ใครไป scrap ที่ไหนมา งานหนักสุด ของงาน scraping คือจัด ข้อความ
		//ให้หัดเล่นกับ format function เยอะๆ
		//ได้ข้อมูลจากที่อื่น ก็ใช่ว่าจะสามารถใช้ โค้ดตัวนี้ ต้องโมใหม่ให้เข้ากับข้อมูลที่ได้มา
		//insert record
		initializers.DB.Model(&models.Products3{}).Create(map[string]interface{}{
			"Productname": productname, "Productdescription": x.Name, "Productprice": x.Price, "Priceformater": x.PriceFormater, "Productquantity": rand.Intn(100), "Urlproductimage_Downloadfrom": x.ImgUrl, "Urlproduct_Image": filelocation_fordb,
		})
	}

	return nil
}

func (data *Data) downoad() error {
	fmt.Println("filename :", data.FileName)
	response, err := http.Get(data.URL)
	if err != nil {
		return err
	}
	defer response.Body.Close()
	if response.StatusCode != 200 {
		return errors.New("Received not 200 response code")
	}
	dir, err := os.Getwd()
	tmppathimage := dir + "\\public\\assets\\uploadfile\\images\\" + data.FileName
	file, err := os.Create(tmppathimage)
	if err != nil {
		return err
	}
	defer file.Close()
	_, err = io.Copy(file, response.Body)
	if err != nil {
		return err
	}
	return nil
}
