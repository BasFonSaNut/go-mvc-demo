package main

import (
	"go-gorm-fiber-colly-mysql/controllers"
	"go-gorm-fiber-colly-mysql/initializers"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/template/html/v2"
)

type ActionResult struct {
	Title   string
	Content string
}

var statusEnv error
var statusConDB error
var statusSyn error

func init() {
	_ = initializers.LoadEnvVariables()
	_ = initializers.ConnectToDB()
	_ = initializers.SyncDB()

}

func main() {
	//template ให้ใช้ตามชอบถนัดได้เลยจะใช้ html style หรือ template style แล้วแต่ชอบ
	//ถามว่าตัวไหนเร็วไปดูได้ที่ https://github.com/gofiber/template เขาทำ Benchmarks ไว้ให้แล้ว
	//ขอเลือก html template เพราะไม่ได้ด้อยมาก อีกอย่างขี้เกียจ map ในรูปแบบ .tmpl style เอาง่ายไม่รกมากนี่แหละนะ
	//ส่วนคนที่จะเขียนสาย webhook หรือ web scraple ต้องใช้ style .tmpl นะเพราะมันยิงจากหลังบ้านไปหน้าบ้านได้ทันที
	//ยิงกันเป็นจุดๆ ไปที่ front-end ตัว template สะดวกสุด คงไม่ไปมีการส่งไปทั้งหน้าเทียบเท่า render ใหม่แบบ project นี้
	//ตัวนี้เอา code แบบ simple สุดเพื่อง่ายต่อการเรียนรู้
	//ส่วนคนที่ถามว่าแล้วทำไมถึงเลือก framework fiber ก็เหตุผลเดียวกัน ตัวไหน Benchemarks ดีไม่เลวร้ายระดับ ขนาด echo framework
	// และง่ายต่อการจบโปรเจค ง่ายต่อการส่งต่องาน เลือกตัวนั้น ดู Go Framework Benchmarks ได้ที่ https://docs.gofiber.io/extra/benchmarks

	//log.Fatal(app.Listen(":3000"))
	enginehtmlStyle := html.New("./views", ".html") //general

	app := fiber.New(fiber.Config{
		Views: enginehtmlStyle,
	})

	app.Static("/", "./public")

	app.Use(cors.New(cors.Config{

		AllowHeaders:     "XMLHttpRequest,X-Requested-With,  Authorization,Origin,Content-Type,Accept,Content-Length,Accept-Language,Accept-Encoding,Connection,Access-Control-Allow-Origin",
		AllowOrigins:     "*",
		AllowCredentials: true,
		AllowMethods:     "GET,POST,HEAD,PUT,DELETE,PATCH,OPTIONS",
	}))

	app.Get("/product/cleardata", controllers.ProductClearData)
	app.Get("/product/createtestdata", controllers.ProductCreateTestData)

	app.Get("/", controllers.ProductIndex)
	app.Get("/product", controllers.ProductIndex)
	app.Get("/product/page/:page", controllers.ProductIndex)

	app.Get("/product/page/:page/searchword/:searchword", controllers.ProductSearch)
	app.Post("/product/search", controllers.SearchProduct)

	app.Get("/product/insertform", controllers.ProductInsertForm)
	app.Post("/product/submitinsert", controllers.InsertProduct)

	app.Get("/product/updateform/:id", controllers.ProductUpdateFrom)
	app.Post("/product/submitupdate", controllers.UpdateProduct)

	app.Get("/product/deleteproduct/:id", controllers.DeleteProduct)

	app.Get("/product/scrapproduct", controllers.ScrapProduct)

	app.Listen(":3000")

	//fmt.Printf("You owe $%s.\n", humanize.Comma(6582491)) // You owe $6,582,491.
}
