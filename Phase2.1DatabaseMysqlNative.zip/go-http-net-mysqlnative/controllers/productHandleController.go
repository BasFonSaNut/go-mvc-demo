package controllers

import (
	"database/sql"
	"fmt"
	"go-httpnet-mysqlnative/models"
	"go-httpnet-mysqlnative/services"

	_ "github.com/go-sql-driver/mysql"
)

func DeleteProduct(id string, MysqlDB *sql.DB) (success bool, result sql.Result, err error) {
	del, err := MysqlDB.Prepare(`DELETE FROM products WHERE Id = ?`)
	if err != nil {
		panic(err)
	}
	defer del.Close()
	result, err = del.Exec(id)
	rowsAff, _ := result.RowsAffected()
	fmt.Println("rowsAff:", rowsAff)

	if err != nil || rowsAff != 1 {
		fmt.Println("Error deleting product")
		success = false
	} else {
		success = true
	}
	return
}

func ProductUpdate(id string, pname string, pdesc string, pprice string, MysqlDB *sql.DB) (success bool, result sql.Result, err error) {
	uby := "Ming"
	uda := services.GetCurrentDateTimeForDB()
	stmt, err := MysqlDB.Prepare(`
		UPDATE products SET productname = ? , 
		productdescription = ?, 
		productprice = ?,
		uby = ? ,
		udate = ?
		WHERE Id = ?;`)
	if err != nil {
		fmt.Println(err)

	} else {
		res, err := stmt.Exec(pname, pdesc, pprice, uby, uda, id)
		if err != nil {
			fmt.Println(err)
		} else {
			result = res
			success = true
		}
	}
	defer stmt.Close()
	return
}

func GetProductById(id string, MysqlDB *sql.DB) (productdata models.Products) {
	fmt.Println("ID is :", id)
	row := MysqlDB.QueryRow(` SELECT 
	Id,
	IFNULL(productname,'') AS Productname,
	IFNULL(productdescription,'') AS Productdescription,
	IFNULL(productquantity,0.00) AS Productquantity,
	IFNULL(productprice,0.00) AS Productprice,
	IFNULL(urlproduct_link,'') AS Urlproduct_link,
	IFNULL(urlproduct_image,'') AS Urlproduct_image,
	IFNULL(cdate,'') AS Cdate,
	IFNULL(cby,'') AS Cby,
	IFNULL(udate,'') AS Udate,
	IFNULL(uby,'') AS Uby 
	FROM products WHERE Id = ?;`, id)

	err := row.Scan(&productdata.Id,
		&productdata.Productname,
		&productdata.Productdescription,
		&productdata.Productquantity,
		&productdata.Productprice,
		&productdata.Urlproduct_Link,
		&productdata.Urlproduct_Image,
		&productdata.Cdate,
		&productdata.Cby,
		&productdata.Udate,
		&productdata.Uby)

	if err != nil {
		fmt.Println(err)
	}
	return
}

func GetAllProduct(MysqlDB *sql.DB) (P []models.Products) {
	stmt := ` SELECT 
			Id,
			IFNULL(productname,'') AS Productname,
			IFNULL(productdescription,'') AS Productdescription,
			IFNULL(productquantity,0.00) AS Productquantity,
			IFNULL(productprice,0.00) AS Productprice,
			IFNULL(urlproduct_link,'') AS Urlproduct_link,
			IFNULL(urlproduct_image,'') AS Urlproduct_image,
			IFNULL(cdate,'') AS Cdate,
			IFNULL(cby,'') AS Cby,
			IFNULL(udate,'') AS Udate,
			IFNULL(uby,'') AS Uby 
	FROM products	`
	rows, err := MysqlDB.Query(stmt)
	if err != nil {
		panic(err)
	}
	// type sql.Row does not have a .Close() Method but sql.Rows does and must be run
	defer rows.Close()
	for rows.Next() {
		var productdata models.Products
		// func (rs *Rows) Scan(dest ...interface{}) error
		err = rows.Scan(
			&productdata.Id,
			&productdata.Productname,
			&productdata.Productdescription,
			&productdata.Productquantity,
			&productdata.Productprice,
			&productdata.Urlproduct_Link,
			&productdata.Urlproduct_Image,
			&productdata.Cdate,
			&productdata.Cby,
			&productdata.Udate,
			&productdata.Uby,
		)
		if err != nil {
			panic(err)
		}
		// func append(slice []Type, elems ...Type) []Type
		P = append(P, productdata)
	}
	return
}

func ProductInsert(pname string, pdesc string, pprice string, MysqlDB *sql.DB) (success bool, result sql.Result, err error) {
	cby := "Ming"
	cda := services.GetCurrentDateTimeForDB()
	stmt, err := MysqlDB.Prepare("INSERT INTO `products` (`productname`, `productdescription`, `productprice`,`cby`,`udate`) VALUES (?, ?, ?, ?, ?);")
	if err != nil {
		fmt.Println(err)

	} else {
		res, err := stmt.Exec(pname, pdesc, pprice, cby, cda)
		if err != nil {
			fmt.Println(err)
		} else {
			result = res
		}
	}
	defer stmt.Close()
	return
}

func ProductSearch(pname string, MysqlDB *sql.DB) (P []models.Products) {
	stmt, err := MysqlDB.Prepare("SELECT * FROM products WHERE productname = ?;")
	if err != nil {
		panic(err)
	}
	defer stmt.Close()

	rows, err := stmt.Query(pname)
	if err != nil {
		panic(err)
	}

	for rows.Next() {
		var productdata models.Products
		err := rows.Scan(
			&productdata.Id,
			&productdata.Productname,
			&productdata.Productdescription,
			&productdata.Productquantity,
			&productdata.Productprice,
			&productdata.Urlproduct_Link,
			&productdata.Urlproduct_Image,
			&productdata.Cdate,
			&productdata.Cby,
			&productdata.Udate,
			&productdata.Uby,
		)
		if err != nil {
			panic(err)
		}
		P = append(P, productdata)
	}
	return
}
