package main

import (
	"database/sql"
	"fmt"
	"html/template"
	"net/http"
	"net/url"
	"os"

	"go-httpnet-mysqlnative/controllers"
	"go-httpnet-mysqlnative/initializers"
	"go-httpnet-mysqlnative/models"
)

var tpl *template.Template
var MysqlDB *sql.DB

func init() {
	initializers.LoadEnvVariables()
}

func main() {
	succuessflag, MysqlDB, err := initializers.DBMysqlNative()
	if err != nil {
		fmt.Println(err)
	} else {
		fmt.Println(succuessflag, MysqlDB)
	}
	defer MysqlDB.Close()

	var port string
	if port = os.Getenv("PORT"); port == "" {
		port = "8080"
	}

	tpl, _ = template.ParseGlob("templates/*.html")

	http.HandleFunc("/", productListHandler)
	http.HandleFunc("/productsearch", productSearchHandler)
	http.HandleFunc("/productinsert", productInsertHandler)
	http.HandleFunc("/insert", productInsertHandler)
	http.HandleFunc("/productlist", productListHandler)
	http.HandleFunc("/edit/", productUpdateHandler)
	http.HandleFunc("/productupdate", productUpdateHandler)
	http.HandleFunc("/delete/", productDeleteHandler)
	http.ListenAndServe("localhost:"+port, nil)
}

func productDeleteHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		fmt.Printf("Req: %s %s %s %s\n", r.Host, r.URL.Path, r.URL.RawQuery, r.RequestURI)
		m, _ := url.ParseQuery(r.URL.RawQuery)
		var id = m["productid"][0]
		fmt.Println(id)
		succuessflag, MysqlDB, err := initializers.DBMysqlNative()
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Println(succuessflag, MysqlDB)
		}
		defer MysqlDB.Close()

		me := models.Meta{
			Title:   "",
			Content: "",
		}

		success, result, err := controllers.DeleteProduct(id, MysqlDB)
		if success {
			rowsAff, _ := result.RowsAffected()
			fmt.Println("Affect Row :", rowsAff, success)
			me = models.Meta{
				Title:   "Delete",
				Content: "Success",
			}
		} else {
			me = models.Meta{
				Title:   "Delete",
				Content: "Fail",
			}
		}
		defer MysqlDB.Close()
		products := controllers.GetAllProduct(MysqlDB)
		tpl.ExecuteTemplate(w, "productlist.html", map[string]interface{}{"Productx": products, "Result": []models.Meta{me}})
	}
}

func productUpdateHandler(w http.ResponseWriter, r *http.Request) {
	me := models.Meta{
		Title:   "",
		Content: "",
	}
	if r.Method == "GET" {
		fmt.Printf("Req: %s %s %s %s\n", r.Host, r.URL.Path, r.URL.RawQuery, r.RequestURI)
		m, _ := url.ParseQuery(r.URL.RawQuery)
		var id = m["productid"][0]
		fmt.Println(id)
		succuessflag, MysqlDB, err := initializers.DBMysqlNative()
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Println(succuessflag, MysqlDB)
		}
		me = models.Meta{Title: "", Content: ""}
		defer MysqlDB.Close()
		product := controllers.GetProductById(id, MysqlDB)
		tpl.ExecuteTemplate(w, "productupdate.html", map[string]interface{}{"Productx": []models.Products{product}, "Result": []models.Meta{me}})
		return
	}

	if r.Method == "POST" {
		r.ParseForm()
		fmt.Println(r)
		Id := r.FormValue("Id")
		pname := r.FormValue("Productname")
		pdesc := r.FormValue("Productdescription")
		pprice := r.FormValue("Productprice")

		succuessflag, MysqlDB, err := initializers.DBMysqlNative()
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Println(succuessflag, MysqlDB)
		}

		if Id == "" || pname == "" || pdesc == "" || pprice == "" {
			me = models.Meta{
				Title:   "Update",
				Content: "Fail : Id,Product Name, Product Description, Product Price not allow null",
			}
			product := controllers.GetProductById(Id, MysqlDB)
			tpl.ExecuteTemplate(w, "productupdate.html", map[string]interface{}{"Productx": []models.Products{product}, "Result": []models.Meta{me}})
			//tpl.ExecuteTemplate(w, "productinsert.html", "Error inserting data, please check all fields.")
			return
		}

		defer MysqlDB.Close()
		fmt.Println("=======================================")
		fmt.Println(Id, pname, pdesc, pprice)
		successflag, result, err := controllers.ProductUpdate(Id, pname, pdesc, pprice, MysqlDB)
		Affectrow, _ := result.RowsAffected()
		if err != nil || Affectrow != 1 {
			me = models.Meta{
				Title:   "Update",
				Content: "Fail",
			}
			fmt.Println("============Error===========================")
			//panic(err.Error()) // proper error handling instead of panic in your app
			product := controllers.GetProductById(Id, MysqlDB)
			tpl.ExecuteTemplate(w, "productupdate.html", map[string]interface{}{"Productx": []models.Products{product}, "Result": []models.Meta{me}})
			return
		}
		me = models.Meta{
			Title:   "Update",
			Content: "Success",
		}

		defer MysqlDB.Close()
		product := controllers.GetProductById(Id, MysqlDB)
		tpl.ExecuteTemplate(w, "productupdate.html", map[string]interface{}{"Productx": []models.Products{product}, "Result": []models.Meta{me}})
		fmt.Println("===============Success========================", successflag)
		return
	}
}

func productListHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Println("*****browseHandler running*****")

	succuessflag, MysqlDB, err := initializers.DBMysqlNative()
	if err != nil {
		fmt.Println(err)
	} else {
		fmt.Println(succuessflag, MysqlDB)
	}
	defer MysqlDB.Close()
	products := controllers.GetAllProduct(MysqlDB)
	me := models.Meta{
		Title:   "",
		Content: "",
	}
	tpl.ExecuteTemplate(w, "productlist.html", map[string]interface{}{"Productx": products, "Result": []models.Meta{me}})
}

func productInsertHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		tpl.ExecuteTemplate(w, "productinsert.html", nil)
		return
	}

	if r.Method == "POST" {
		r.ParseForm()
		fmt.Println(r)
		pname := r.FormValue("Productname")
		pdesc := r.FormValue("Productdescription")
		pprice := r.FormValue("Productprice")

		succuessflag, MysqlDB, err := initializers.DBMysqlNative()
		if err != nil {
			fmt.Println(err)
		} else {
			fmt.Println(succuessflag, MysqlDB)
		}

		if pname == "" || pdesc == "" || pprice == "" {
			tpl.ExecuteTemplate(w, "productinsert.html", "Error inserting data, please check all fields.")
			return
		}

		defer MysqlDB.Close()
		fmt.Println("=======================================")
		fmt.Println(pname, pdesc, pprice)
		successflag, result, err := controllers.ProductInsert(pname, pdesc, pprice, MysqlDB)
		if err != nil {
			fmt.Println("=======================================")
			panic(err.Error()) // proper error handling instead of panic in your app

		} else {
			fmt.Println("=======================================")
			fmt.Println(successflag)
			fmt.Println(result.LastInsertId())
			tpl.ExecuteTemplate(w, "productinsert.html", "Product Successfully Inserted")
		}
	}
}

func productSearchHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method == "GET" {
		tpl.ExecuteTemplate(w, "productsearch.html", nil)
		return
	}

	if r.Method == "POST" {
		r.ParseForm()

		succuessflag, MysqlDB, err := initializers.DBMysqlNative()

		if err != nil {
			fmt.Println(err)
		} else {
			// defer MysqlDB.Close()
			fmt.Print(succuessflag, MysqlDB)
			fmt.Println(r)

			name := r.FormValue("productName")
			fmt.Println("name:", name)
			P := controllers.ProductSearch(name, MysqlDB)
			fmt.Println(P)
			tpl.ExecuteTemplate(w, "productsearch.html", P)
		}
	}
}
