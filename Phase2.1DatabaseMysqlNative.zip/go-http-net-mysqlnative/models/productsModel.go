package models

// Product table mysql native
type Products struct {
	Id                 int
	Productname        string
	Productdescription string
	Productquantity    []uint8
	Productprice       float32
	Urlproduct_Link    string
	Urlproduct_Image   string
	Cdate              string
	Cby                string
	Udate              string
	Uby                string
}

type Meta struct {
	Title   string
	Content string
}
