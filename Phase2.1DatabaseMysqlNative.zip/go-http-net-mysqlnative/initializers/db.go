package initializers

import (
	"database/sql"
	"fmt"
	"os"

	_ "github.com/go-sql-driver/mysql"
)

var MysqlDB *sql.DB

func ConnectMysqlNative() {
	MysqlDB, err := sql.Open("mysql", os.Getenv("DBMYSQNATIVE_URL"))
	if err != nil {
		fmt.Println("Failed to connect to db", MysqlDB)
	}
}

func DBMysqlNative() (successflag bool, mysqlnativedb *sql.DB, err error) {
	dsn := os.Getenv("DBMYSQNATIVE_URL")
	mysqlnativedb, err = sql.Open("mysql", dsn)
	if err != nil {
		successflag = false
		panic(err)
	} else {
		successflag = true
		// See "Important settings" section.
		// mysqlnativedb.SetConnMaxLifetime(time.Minute * 3)
		// mysqlnativedb.SetMaxOpenConns(10)
		// mysqlnativedb.SetMaxIdleConns(10)
	}
	return

}
