-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2023 at 10:29 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `go-mvc`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `productname` varchar(400) DEFAULT NULL,
  `productdescription` text DEFAULT NULL,
  `productquantity` int(11) DEFAULT 0,
  `productprice` float DEFAULT 0,
  `urlproduct_link` varchar(1000) DEFAULT NULL,
  `urlproduct_image` varchar(2000) DEFAULT NULL,
  `cdate` datetime NOT NULL DEFAULT current_timestamp(),
  `cby` varchar(1000) DEFAULT NULL,
  `udate` datetime DEFAULT NULL,
  `uby` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `productname`, `productdescription`, `productquantity`, `productprice`, `urlproduct_link`, `urlproduct_image`, `cdate`, `cby`, `udate`, `uby`) VALUES
(14, 'test3', 'test3', 0, 15, NULL, NULL, '2023-08-30 22:45:21', 'Ming', '2023-08-31 15:26:12', 'Ming'),
(16, 'test1', 'test2', 0, 10, NULL, NULL, '2023-08-31 14:52:29', 'Ming', '2023-08-31 14:52:29', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
