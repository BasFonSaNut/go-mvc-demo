package models

import (
	"gorm.io/gorm"
)

type Products3 struct {
	gorm.Model
	Id                 uint64 `json:"id" sql:"AUTO_INCREMENT" gorm:"primary_key"`
	Productname        string
	Productdescription string
	Productquantity    string
	Productprice       float32
	Urlproduct_Link    string
	Urlproduct_Image   string
	Cdate              string
	Cby                string
	Udate              string
	Uby                string
	CreatedAt          []uint8
	UpdatedAt          []uint8
	DeletedAt          gorm.DeletedAt `gorm:"index"`
}

type Meta struct {
	Title   string
	Content string
}

type ActionResult struct {
	Title   string
	Content string
}

type FakeProduct struct {
	PName  string  `fake:"{beername}"`
	PDesc  string  `fake:"{loremipsumsentence:10}"`
	PPrice float32 `fake:"{price:10,20}"`
}
