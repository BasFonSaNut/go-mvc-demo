package helpers

import (
	"fmt"
	"go-gorm-fiber-mysql/initializers"
	"math"
)

type PaginationData struct {
	NextPage     int
	PreviousPage int
	CurrentPage  int
	TotalPages   int
	TwoAfter     int
	TwoBelow     int
	Offset       int
	BaseURL      string
}

func GetpaginationData(page int, perPage int, model interface{}, baseURL string) PaginationData {
	// calculate total page
	var totalRows int64
	initializers.DB.Model(model).Count(&totalRows)
	totalPages := int64(math.Ceil(float64(float64(totalRows) / float64(perPage))))
	fmt.Println("Total Page is ", totalPages)

	if totalRows == 0 {
		return PaginationData{
			NextPage:     0,
			PreviousPage: 0,
			CurrentPage:  1,
			TotalPages:   0,
			TwoAfter:     0,
			TwoBelow:     0,
			Offset:       0,
			BaseURL:      baseURL,
		}
	}
	//calculate offset
	offset := (page - 1) * perPage
	return PaginationData{
		NextPage:     page + 1,
		PreviousPage: page - 1,
		CurrentPage:  page,
		TotalPages:   int(totalPages),
		TwoAfter:     page + 2,
		TwoBelow:     page - 2,
		Offset:       offset,
		BaseURL:      baseURL,
	}
}
