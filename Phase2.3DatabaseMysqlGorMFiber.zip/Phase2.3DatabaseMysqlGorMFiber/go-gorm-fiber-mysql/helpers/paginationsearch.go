package helpers

import (
	"fmt"
	"math"
	"strconv"

	"github.com/bradfitz/iter"
)

type TotalRows struct {
	Title    string
	TotalRow int
	Offset   int
}

type PageStatic struct {
	Id           int
	Content      string
	NextPage     int
	PreviousPage int
	CurrentPage  int
	TotalPages   int
	TwoAfter     int
	TwoBelow     int
	BaseURL      string
	Searchword   string
}

func GetpaginationSearchwordData(page int, perPage int, allRows int64, model interface{}, baseURL string, searchword string) (TotalRows, []PageStatic) {
	// calculate total page
	var totalRows int64

	//initializers.DB.Model(model).Count(&totalRows)
	totalPages := int64(math.Ceil(float64(float64(allRows) / float64(perPage))))
	fmt.Println("Total Page is ", int(totalPages), "Total Row :", totalRows)
	totalRowsc, _ := strconv.Atoi(strconv.FormatInt(allRows, 10))
	totalPagesc, _ := strconv.Atoi(strconv.FormatInt(totalPages, 10))

	var PageallStatic []PageStatic

	offset := (page - 1)
	for i := range iter.N(totalPagesc) {
		var hrefpattern = `<a href="{{ .BaseURL }}/page/{{ .Id }}/searchword/{{ .Searchword }}">[{{ .Id }}]</a>`
		var pagenumber = (i + 1)
		PageallStatic = append(PageallStatic, PageStatic{
			Id:           pagenumber,
			Content:      hrefpattern,
			NextPage:     page + 1,
			PreviousPage: page - 1,
			CurrentPage:  page,
			TotalPages:   int(totalPages),
			TwoAfter:     page + 2,
			TwoBelow:     page - 2,
			BaseURL:      baseURL,
			Searchword:   searchword,
		})
	}

	//calculate offset

	return TotalRows{
		Title:    "Total Rows",
		TotalRow: totalRowsc,
		Offset:   offset,
	}, PageallStatic
}
