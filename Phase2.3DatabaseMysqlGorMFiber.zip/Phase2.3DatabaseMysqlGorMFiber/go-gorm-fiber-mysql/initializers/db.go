package initializers

import (
	"fmt"
	"go-gorm-fiber-mysql/models"
	"os"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

var DB *gorm.DB

func SyncDB() error {
	DB.AutoMigrate(&models.Products3{})
	return nil
}

func ConnectToDB() error {
	var err error
	DB, err = gorm.Open(mysql.Open(os.Getenv("DBMYSQL_URL")), &gorm.Config{})

	if err != nil {
		fmt.Println("Failed to connect to db")
	}
	return nil
}
